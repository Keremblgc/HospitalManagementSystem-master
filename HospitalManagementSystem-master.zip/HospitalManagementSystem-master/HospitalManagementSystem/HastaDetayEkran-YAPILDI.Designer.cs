﻿
namespace HospitalManagementSystem
{
    partial class HastaDetayEkran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HastaDetayEkran));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.AktifRandevuDataGrid = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblHastaAdSoyad = new System.Windows.Forms.Label();
            this.yeniRandevuAlBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.hastaGEkraniCıkısBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblHastaTC = new System.Windows.Forms.Label();
            this.bilgileriniGuncelle = new System.Windows.Forms.Button();
            this.txtRandevuIptal = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AktifRandevuDataGrid)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hastaGEkraniCıkısBtn)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(4, 601);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(8, 601);
            this.panel2.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(8, 601);
            this.panel5.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(4, 520);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(667, 8);
            this.panel6.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(671, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(4, 601);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(4, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(667, 4);
            this.panel4.TabIndex = 4;
            // 
            // AktifRandevuDataGrid
            // 
            this.AktifRandevuDataGrid.AllowUserToAddRows = false;
            this.AktifRandevuDataGrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AktifRandevuDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.AktifRandevuDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AktifRandevuDataGrid.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.AktifRandevuDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AktifRandevuDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AktifRandevuDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.AktifRandevuDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AktifRandevuDataGrid.DoubleBuffered = true;
            this.AktifRandevuDataGrid.EnableHeadersVisualStyles = false;
            this.AktifRandevuDataGrid.GridColor = System.Drawing.Color.WhiteSmoke;
            this.AktifRandevuDataGrid.HeaderBgColor = System.Drawing.Color.Transparent;
            this.AktifRandevuDataGrid.HeaderForeColor = System.Drawing.Color.Transparent;
            this.AktifRandevuDataGrid.Location = new System.Drawing.Point(0, 24);
            this.AktifRandevuDataGrid.Margin = new System.Windows.Forms.Padding(2);
            this.AktifRandevuDataGrid.Name = "AktifRandevuDataGrid";
            this.AktifRandevuDataGrid.ReadOnly = true;
            this.AktifRandevuDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.AktifRandevuDataGrid.RowHeadersWidth = 51;
            this.AktifRandevuDataGrid.RowTemplate.Height = 24;
            this.AktifRandevuDataGrid.Size = new System.Drawing.Size(635, 157);
            this.AktifRandevuDataGrid.TabIndex = 0;
            this.AktifRandevuDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AktifRandevuDataGrid_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AktifRandevuDataGrid);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBox1.Location = new System.Drawing.Point(20, 141);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(635, 180);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Aktif Randevularınız";
            // 
            // bunifuCustomDataGrid1
            // 
            this.bunifuCustomDataGrid1.AllowUserToAddRows = false;
            this.bunifuCustomDataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.bunifuCustomDataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.GridColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.Transparent;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Transparent;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(0, 20);
            this.bunifuCustomDataGrid1.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.ReadOnly = true;
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.RowHeadersWidth = 51;
            this.bunifuCustomDataGrid1.RowTemplate.Height = 24;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(642, 168);
            this.bunifuCustomDataGrid1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuCustomDataGrid1);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.DarkRed;
            this.groupBox2.Location = new System.Drawing.Point(20, 385);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(635, 188);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Geçmiş Randevularınız";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(4, 597);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(667, 4);
            this.panel7.TabIndex = 12;
            // 
            // lblHastaAdSoyad
            // 
            this.lblHastaAdSoyad.AutoSize = true;
            this.lblHastaAdSoyad.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHastaAdSoyad.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblHastaAdSoyad.Location = new System.Drawing.Point(4, 74);
            this.lblHastaAdSoyad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHastaAdSoyad.Name = "lblHastaAdSoyad";
            this.lblHastaAdSoyad.Size = new System.Drawing.Size(54, 21);
            this.lblHastaAdSoyad.TabIndex = 14;
            this.lblHastaAdSoyad.Text = "aaaa";
            // 
            // yeniRandevuAlBtn
            // 
            this.yeniRandevuAlBtn.ActiveBorderThickness = 1;
            this.yeniRandevuAlBtn.ActiveCornerRadius = 20;
            this.yeniRandevuAlBtn.ActiveFillColor = System.Drawing.Color.DarkCyan;
            this.yeniRandevuAlBtn.ActiveForecolor = System.Drawing.Color.White;
            this.yeniRandevuAlBtn.ActiveLineColor = System.Drawing.Color.DarkCyan;
            this.yeniRandevuAlBtn.BackColor = System.Drawing.Color.White;
            this.yeniRandevuAlBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("yeniRandevuAlBtn.BackgroundImage")));
            this.yeniRandevuAlBtn.ButtonText = "Yeni Randevu Al";
            this.yeniRandevuAlBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yeniRandevuAlBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeniRandevuAlBtn.ForeColor = System.Drawing.Color.CadetBlue;
            this.yeniRandevuAlBtn.IdleBorderThickness = 1;
            this.yeniRandevuAlBtn.IdleCornerRadius = 20;
            this.yeniRandevuAlBtn.IdleFillColor = System.Drawing.Color.White;
            this.yeniRandevuAlBtn.IdleForecolor = System.Drawing.Color.CadetBlue;
            this.yeniRandevuAlBtn.IdleLineColor = System.Drawing.Color.CadetBlue;
            this.yeniRandevuAlBtn.Location = new System.Drawing.Point(491, 102);
            this.yeniRandevuAlBtn.Margin = new System.Windows.Forms.Padding(4);
            this.yeniRandevuAlBtn.Name = "yeniRandevuAlBtn";
            this.yeniRandevuAlBtn.Size = new System.Drawing.Size(158, 40);
            this.yeniRandevuAlBtn.TabIndex = 16;
            this.yeniRandevuAlBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.yeniRandevuAlBtn.Click += new System.EventHandler(this.yeniRandevuAlBtn_Click);
            // 
            // hastaGEkraniCıkısBtn
            // 
            this.hastaGEkraniCıkısBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hastaGEkraniCıkısBtn.BackColor = System.Drawing.Color.White;
            this.hastaGEkraniCıkısBtn.Image = ((System.Drawing.Image)(resources.GetObject("hastaGEkraniCıkısBtn.Image")));
            this.hastaGEkraniCıkısBtn.ImageActive = null;
            this.hastaGEkraniCıkısBtn.Location = new System.Drawing.Point(632, 7);
            this.hastaGEkraniCıkısBtn.Margin = new System.Windows.Forms.Padding(2);
            this.hastaGEkraniCıkısBtn.Name = "hastaGEkraniCıkısBtn";
            this.hastaGEkraniCıkısBtn.Size = new System.Drawing.Size(38, 45);
            this.hastaGEkraniCıkısBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hastaGEkraniCıkısBtn.TabIndex = 17;
            this.hastaGEkraniCıkısBtn.TabStop = false;
            this.hastaGEkraniCıkısBtn.Zoom = 5;
            this.hastaGEkraniCıkısBtn.Click += new System.EventHandler(this.hastaGEkraniCıkısBtn_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblHastaTC);
            this.groupBox3.Controls.Add(this.lblHastaAdSoyad);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.groupBox3.Location = new System.Drawing.Point(20, 21);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(240, 114);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Hoşgeldiniz";
            // 
            // lblHastaTC
            // 
            this.lblHastaTC.AutoSize = true;
            this.lblHastaTC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHastaTC.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblHastaTC.Location = new System.Drawing.Point(4, 32);
            this.lblHastaTC.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHastaTC.Name = "lblHastaTC";
            this.lblHastaTC.Size = new System.Drawing.Size(54, 21);
            this.lblHastaTC.TabIndex = 15;
            this.lblHastaTC.Text = "aaaa";
            // 
            // bilgileriniGuncelle
            // 
            this.bilgileriniGuncelle.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bilgileriniGuncelle.FlatAppearance.BorderColor = System.Drawing.Color.DarkCyan;
            this.bilgileriniGuncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bilgileriniGuncelle.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.bilgileriniGuncelle.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.bilgileriniGuncelle.Location = new System.Drawing.Point(459, 11);
            this.bilgileriniGuncelle.Margin = new System.Windows.Forms.Padding(2);
            this.bilgileriniGuncelle.Name = "bilgileriniGuncelle";
            this.bilgileriniGuncelle.Size = new System.Drawing.Size(152, 32);
            this.bilgileriniGuncelle.TabIndex = 19;
            this.bilgileriniGuncelle.Text = "Bilgilerimi Güncelle";
            this.bilgileriniGuncelle.UseVisualStyleBackColor = true;
            this.bilgileriniGuncelle.Click += new System.EventHandler(this.bilgileriniGuncelle_Click);
            // 
            // txtRandevuIptal
            // 
            this.txtRandevuIptal.ActiveBorderThickness = 1;
            this.txtRandevuIptal.ActiveCornerRadius = 20;
            this.txtRandevuIptal.ActiveFillColor = System.Drawing.Color.DarkCyan;
            this.txtRandevuIptal.ActiveForecolor = System.Drawing.Color.White;
            this.txtRandevuIptal.ActiveLineColor = System.Drawing.Color.DarkCyan;
            this.txtRandevuIptal.BackColor = System.Drawing.Color.White;
            this.txtRandevuIptal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtRandevuIptal.BackgroundImage")));
            this.txtRandevuIptal.ButtonText = "Randevu İptal Et";
            this.txtRandevuIptal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtRandevuIptal.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRandevuIptal.ForeColor = System.Drawing.Color.CadetBlue;
            this.txtRandevuIptal.IdleBorderThickness = 1;
            this.txtRandevuIptal.IdleCornerRadius = 20;
            this.txtRandevuIptal.IdleFillColor = System.Drawing.Color.White;
            this.txtRandevuIptal.IdleForecolor = System.Drawing.Color.CadetBlue;
            this.txtRandevuIptal.IdleLineColor = System.Drawing.Color.CadetBlue;
            this.txtRandevuIptal.Location = new System.Drawing.Point(497, 339);
            this.txtRandevuIptal.Margin = new System.Windows.Forms.Padding(4);
            this.txtRandevuIptal.Name = "txtRandevuIptal";
            this.txtRandevuIptal.Size = new System.Drawing.Size(158, 40);
            this.txtRandevuIptal.TabIndex = 20;
            this.txtRandevuIptal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtRandevuIptal.Click += new System.EventHandler(this.txtRandevuIptal_Click);
            // 
            // HastaDetayEkran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(675, 601);
            this.Controls.Add(this.txtRandevuIptal);
            this.Controls.Add(this.bilgileriniGuncelle);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.hastaGEkraniCıkısBtn);
            this.Controls.Add(this.yeniRandevuAlBtn);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HastaDetayEkran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HastaDetayEkran";
            this.Load += new System.EventHandler(this.HastaDetayEkran_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AktifRandevuDataGrid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hastaGEkraniCıkısBtn)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuCustomDataGrid AktifRandevuDataGrid;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lblHastaAdSoyad;
        private Bunifu.Framework.UI.BunifuThinButton2 yeniRandevuAlBtn;
        private Bunifu.Framework.UI.BunifuImageButton hastaGEkraniCıkısBtn;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblHastaTC;
        private System.Windows.Forms.Button bilgileriniGuncelle;
        private Bunifu.Framework.UI.BunifuThinButton2 txtRandevuIptal;
    }
}