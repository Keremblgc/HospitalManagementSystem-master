﻿
namespace HospitalManagementSystem
{
    partial class TaburcuOlanHastalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TaburcuOlanHastalar));
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.bunifuCustomDataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.UcretBilgisi = new System.Windows.Forms.Label();
            this.hastaGEkraniCıkısBtn = new Bunifu.Framework.UI.BunifuImageButton();
            this.bitirButon = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hastaGEkraniCıkısBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(4, 493);
            this.panel4.TabIndex = 50;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(675, 4);
            this.panel2.TabIndex = 49;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.button1);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(4, 493);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(667, 4);
            this.panel6.TabIndex = 52;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 19);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(671, 4);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(4, 493);
            this.panel5.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label4.Location = new System.Drawing.Point(34, 44);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(186, 21);
            this.label4.TabIndex = 54;
            this.label4.Text = "Taburcu Olan Hastalar";
            // 
            // bunifuCustomDataGrid1
            // 
            this.bunifuCustomDataGrid1.AllowUserToAddRows = false;
            this.bunifuCustomDataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuCustomDataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.bunifuCustomDataGrid1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuCustomDataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DarkGray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuCustomDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.bunifuCustomDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bunifuCustomDataGrid1.DoubleBuffered = true;
            this.bunifuCustomDataGrid1.EnableHeadersVisualStyles = false;
            this.bunifuCustomDataGrid1.HeaderBgColor = System.Drawing.Color.DarkGray;
            this.bunifuCustomDataGrid1.HeaderForeColor = System.Drawing.Color.Black;
            this.bunifuCustomDataGrid1.Location = new System.Drawing.Point(38, 100);
            this.bunifuCustomDataGrid1.Margin = new System.Windows.Forms.Padding(2);
            this.bunifuCustomDataGrid1.Name = "bunifuCustomDataGrid1";
            this.bunifuCustomDataGrid1.ReadOnly = true;
            this.bunifuCustomDataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.bunifuCustomDataGrid1.RowHeadersWidth = 51;
            this.bunifuCustomDataGrid1.RowTemplate.Height = 24;
            this.bunifuCustomDataGrid1.Size = new System.Drawing.Size(604, 268);
            this.bunifuCustomDataGrid1.TabIndex = 53;
            this.bunifuCustomDataGrid1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuCustomDataGrid1_CellClick);
            this.bunifuCustomDataGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuCustomDataGrid1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label1.Location = new System.Drawing.Point(378, 418);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 20);
            this.label1.TabIndex = 55;
            this.label1.Text = "Toplam Ücret";
            // 
            // UcretBilgisi
            // 
            this.UcretBilgisi.AutoSize = true;
            this.UcretBilgisi.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.UcretBilgisi.Location = new System.Drawing.Point(488, 418);
            this.UcretBilgisi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.UcretBilgisi.Name = "UcretBilgisi";
            this.UcretBilgisi.Size = new System.Drawing.Size(159, 20);
            this.UcretBilgisi.TabIndex = 56;
            this.UcretBilgisi.Text = "Ücret Bilgisi Gelecek";
            // 
            // hastaGEkraniCıkısBtn
            // 
            this.hastaGEkraniCıkısBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hastaGEkraniCıkısBtn.BackColor = System.Drawing.Color.White;
            this.hastaGEkraniCıkısBtn.Image = ((System.Drawing.Image)(resources.GetObject("hastaGEkraniCıkısBtn.Image")));
            this.hastaGEkraniCıkısBtn.ImageActive = null;
            this.hastaGEkraniCıkısBtn.Location = new System.Drawing.Point(630, 10);
            this.hastaGEkraniCıkısBtn.Margin = new System.Windows.Forms.Padding(2);
            this.hastaGEkraniCıkısBtn.Name = "hastaGEkraniCıkısBtn";
            this.hastaGEkraniCıkısBtn.Size = new System.Drawing.Size(36, 36);
            this.hastaGEkraniCıkısBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hastaGEkraniCıkısBtn.TabIndex = 57;
            this.hastaGEkraniCıkısBtn.TabStop = false;
            this.hastaGEkraniCıkısBtn.Zoom = 10;
            this.hastaGEkraniCıkısBtn.Click += new System.EventHandler(this.hastaGEkraniCıkısBtn_Click);
            // 
            // bitirButon
            // 
            this.bitirButon.ActiveBorderThickness = 1;
            this.bitirButon.ActiveCornerRadius = 20;
            this.bitirButon.ActiveFillColor = System.Drawing.Color.CadetBlue;
            this.bitirButon.ActiveForecolor = System.Drawing.Color.White;
            this.bitirButon.ActiveLineColor = System.Drawing.Color.CadetBlue;
            this.bitirButon.BackColor = System.Drawing.Color.White;
            this.bitirButon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bitirButon.BackgroundImage")));
            this.bitirButon.ButtonText = "İşlem Bitir";
            this.bitirButon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bitirButon.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bitirButon.ForeColor = System.Drawing.Color.CadetBlue;
            this.bitirButon.IdleBorderThickness = 1;
            this.bitirButon.IdleCornerRadius = 20;
            this.bitirButon.IdleFillColor = System.Drawing.Color.White;
            this.bitirButon.IdleForecolor = System.Drawing.Color.CadetBlue;
            this.bitirButon.IdleLineColor = System.Drawing.Color.CadetBlue;
            this.bitirButon.Location = new System.Drawing.Point(551, 449);
            this.bitirButon.Margin = new System.Windows.Forms.Padding(4);
            this.bitirButon.Name = "bitirButon";
            this.bitirButon.Size = new System.Drawing.Size(96, 35);
            this.bitirButon.TabIndex = 58;
            this.bitirButon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bitirButon.Click += new System.EventHandler(this.bitirButon_Click);
            // 
            // TaburcuOlanHastalar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(675, 497);
            this.Controls.Add(this.bitirButon);
            this.Controls.Add(this.hastaGEkraniCıkısBtn);
            this.Controls.Add(this.UcretBilgisi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.bunifuCustomDataGrid1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TaburcuOlanHastalar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TaburcuOlanHastalar";
            this.Load += new System.EventHandler(this.TaburcuOlanHastalar_Load);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuCustomDataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hastaGEkraniCıkısBtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuCustomDataGrid bunifuCustomDataGrid1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label UcretBilgisi;
        private Bunifu.Framework.UI.BunifuImageButton hastaGEkraniCıkısBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 bitirButon;
    }
}